<?php

  // Headers
  if($_SERVER['PHP_SELF']=="/api.php/users")
{
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  include_once 'E:\XAMP\XAMPcontinue\htdocs\DB.php';
  include_once 'E:\XAMP\XAMPcontinue\htdocs\Post.php';
  $database = new DB();
  $db = $database->connect();

  $category = new Post($db);

  $sth = $db->prepare("SELECT * FROM users");
  $sth->execute();

  $arr=$sth->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode($arr);


}

if($_SERVER['PHP_SELF']=="/api.php/register")
{

    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');
    // Headers
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    include_once 'E:\XAMP\XAMPcontinue\htdocs\DB.php';
    include_once 'E:\XAMP\XAMPcontinue\htdocs\Post.php';
    // Instantiate DB & connect
  
  
    $database = new DB();
    $db = $database->connect();
    // Instantiate blog category object
    $category = new Post($db);
  
    $data=json_decode(file_get_contents("php://input"));
    
    $nameErr = $famErr = $mailErr = $passErr = "";
    
  $category->email=$data->email;
  $category->first_name=$data->first_name;
  $category->last_name=$data->last_name;
  $category->password=$data->password;
  $category->role=$data->role;
  
  if (!(strlen($category->first_name)>0 && strlen($category->first_name)<=100)) {
      $nameErr = "not valid";
     
    } else {
      $category->first_name=$data->first_name;
    }
    
    if (!(strlen($category->last_name)>0 && strlen($category->last_name)<=100)) {
      $famErr = "not valid";
      
    } else {
      $category->last_name=$data->last_name;
      
    }
      
    if (!(strlen($category->email)>0 && strlen($category->email)<=255)) {
      $mailErr = "not valid";
      
    } else {
      $category->email=$data->email;
    }
  
    if (!(strlen($category->password)>0 && strlen($category->password)<=2056)) {
        $passErr = "not valid";
        
      } else {
          $category->password=$data->password;
          $category->password=hash('ripemd160', $category->password);
      }
      if($nameErr!="not valid" && $mailErr!="not valid" && $famErr!="not valid" && $passErr!="not valid" )
      {
  if($category->create())
  {
      echo json_encode(
      array('message'=>'inserted')
      );
  }
  else{
      echo json_encode(
          array('messge'=>'fail')
      );
  }
      }
}

$email="";
if(preg_match("/\/api.php\/user\/.+/",$_SERVER['PHP_SELF']))
{
    header('Access-Control-Allow-Methods: DELETE');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');
  
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    include_once 'E:\XAMP\XAMPcontinue\htdocs\DB.php';
    include_once 'E:\XAMP\XAMPcontinue\htdocs\Post.php';
    // Instantiate DB & connect
    $database = new DB();
    $db = $database->connect();
    // Instantiate blog post object
    $category = new Post($db);
    // Get raw posted data
    // Set ID to UPDATE
    // Delete post
    $check=explode('/',$_SERVER['PHP_SELF']);

    if($category->delete($check[count($check)-1])) {
      echo json_encode(
        array('message' => 'Category deleted')
      );
    } else {
      echo json_encode(
        array('message' => 'Category not deleted')
      );
    }
}

  ?>