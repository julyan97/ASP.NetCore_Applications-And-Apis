<?php
class DB
{
private $dsn="mysql:host=localhost;dbname=registration;charset=utf8";
private $username="root";
private $password="";
private $db;
    function connect()
    {

$db=null;

try{
    $db=new PDO("mysql:host=localhost;dbname=registration;charset=utf8"
    ,"root",'');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    
}
catch(PROExceprion $e)
{
  $error_message = $e->getMessege();
  echo $error_message;
   
}

return $db;
    }
}
?>